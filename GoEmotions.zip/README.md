The contents of this directory have been moved to https://storage.googleapis.com/gresearch/goemotions/data/full_dataset/

To copy:

```
gsutil cp -r gs://gresearch/goemotions/data/full_dataset/ .
```
